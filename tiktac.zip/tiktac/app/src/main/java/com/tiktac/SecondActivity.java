package com.tiktac;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Button btnMain;

        btnMain = findViewById(R.id.button2);

        Intent iNext;

        iNext = new Intent(SecondActivity.this,MainActivity.class);
        iNext.putExtra("title","Home");
        iNext.putExtra("Student","hasnain");
        iNext.putExtra("Roll no",10);

        btnMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(iNext);
            }
        });


    }
}


